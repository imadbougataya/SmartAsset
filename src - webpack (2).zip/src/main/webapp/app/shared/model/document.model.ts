import dayjs from 'dayjs';
import { IAsset } from 'app/shared/model/asset.model';

export interface IDocument {
  id?: number;
  fileName?: string;
  mimeType?: string;
  sizeBytes?: number | null;
  storageRef?: string;
  checksumSha256?: string | null;
  uploadedAt?: dayjs.Dayjs;
  uploadedBy?: string | null;
  asset?: IAsset;
}

export const defaultValue: Readonly<IDocument> = {};
