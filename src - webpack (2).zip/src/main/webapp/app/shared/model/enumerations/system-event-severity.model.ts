export enum SystemEventSeverity {
  INFO = 'INFO',

  WARNING = 'WARNING',

  ERROR = 'ERROR',
}
