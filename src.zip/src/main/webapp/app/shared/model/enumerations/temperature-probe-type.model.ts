export enum TemperatureProbeType {
  NONE = 'NONE',

  PTC = 'PTC',

  PT100 = 'PT100',

  PT1000 = 'PT1000',
}
