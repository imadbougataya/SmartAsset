export enum LocationSource {
  BLE = 'BLE',

  GNSS = 'GNSS',

  MANUAL = 'MANUAL',
}
