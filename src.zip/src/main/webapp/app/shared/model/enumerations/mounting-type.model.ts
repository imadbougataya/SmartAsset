export enum MountingType {
  B3 = 'B3',

  B5 = 'B5',

  V1 = 'V1',

  B14 = 'B14',

  B35 = 'B35',

  UNKNOWN = 'UNKNOWN',
}
