export enum AssetStatus {
  ACTIVE = 'ACTIVE',

  INACTIVE = 'INACTIVE',

  OUT_OF_SERVICE = 'OUT_OF_SERVICE',

  LOST = 'LOST',

  SCRAPPED = 'SCRAPPED',
}
